#include "Parameter.h"

std::string Parameter::ToString() {
    return p;
}